    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

/**
 *
 * @author Dan
 */
import java.rmi.*;

public interface ChatServerInt extends Remote {

    void tellOthers(Messagedata msg) throws RemoteException;

    void register(ClientInt clientRef) throws
            RemoteException;

    void unRegister(ClientInt clientRef) throws
            RemoteException;
}
