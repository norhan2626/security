/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Dan
 */
public interface ClientInt extends Remote {

    void receive(Messagedata msg) throws RemoteException;
}
