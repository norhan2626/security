/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.io.IOException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Vector;


/**
 *
 * @author Dan
 */
public class Controller {

    Model model;
    ChatServerInt interfaceserver;
    
    View view;
    Registry reg;
 
  
   

   public  Controller(View view) {
    this.view=view;
            try {
           
             model = new Model(this);
             
            this.reg = LocateRegistry.getRegistry(1800);
         
            
            interfaceserver = (ChatServerInt) reg.lookup("chat1");
                  
            interfaceserver.register(model);
            System.out.println("test");
           
            System.out.println("tes1");
        } catch (RemoteException | NotBoundException ex) {
            ex.printStackTrace();
        }
    }
    

    public void displayMsg(Messagedata msg) throws RemoteException {
        System.out.println("test");
        System.out.println("ss"+interfaceserver.toString());
       
        view.display(msg);
    }

    public void sendMsg(Messagedata msg) throws RemoteException {
        
         msg.setClient(model);
        interfaceserver.tellOthers(msg);

    }


}
