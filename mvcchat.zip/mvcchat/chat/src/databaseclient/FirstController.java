/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;



/**
 *
 * @author Dan
 */
public class FirstController implements Initializable {

    @FXML
    private Label label;

    Stage stages = new Stage();

    @FXML
    private ImageView imag;

    @FXML
    private TextField name;

    String imageUrl;
    public static  Image image1;
    public static  String im1="noImage";
    public static  String nameString = "";
    
    public void setStages(Stage stages) {
        this.stages = stages;
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void yallaAction(ActionEvent event) throws IOException {

        nameString = name.getText();

        String newWords = nameString.replaceAll("\\s+", "");

        if (newWords.equals("")) {

            label.setText("Please Enter Your Name");
        } else {
            String newText = nameString.replace(" ", "").toLowerCase().trim();
            nameString = name.getText().trim();

            try {
                
                Parent root = FXMLLoader.load(getClass().getResource("SecondDocument.fxml"));
                ///////////////////////////
                
                Scene scene = new Scene(root, 700, 550);

                stages.setTitle("New Window");
                stages.setScene(scene);
                
                stages.show();
                
            } catch (IOException e) {

                e.printStackTrace();
            }
        }
    }
    final FileChooser fileChooser = new FileChooser();

    @FXML
    private void choosePic(ActionEvent event) throws MalformedURLException {

        File file = fileChooser.showOpenDialog(stages);
       if (file != null) {
            //,receiver,
            //message.split(",receiever,")[0] or 1 according to the arrangement or the index
           im1=  file.toURI().toString();
            System.out.println("image"+im1);
            image1 = new Image(file.toURI().toString());

            //ImageView ip = new ImageView(image1);
            imag.setImage(image1);

        }else{
           
           im1=new String("noImage");
       }

    }
}
