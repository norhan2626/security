/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Dan
 */
public class Model extends UnicastRemoteObject implements ClientInt {

    Controller controller;

    public Model() throws RemoteException {

    }

    public Model(Controller c) throws RemoteException {

        controller = c;
//super();
    }
//

    @Override
    public void receive(Messagedata msg) throws RemoteException {

        System.out.println("Messge received: " + msg);
        controller.displayMsg(msg);
    }

}
