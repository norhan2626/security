/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Dan
 */
public class Secondscene extends Application {

    @Override
    public void start(Stage stage) throws Exception {
       /* Parent root = FXMLLoader.load(getClass().getResource("SecondDocument.fxml"));

        Scene scene = new Scene(root);
        root.getStylesheets().add(getClass().getResource("MyStyle.css").toExternalForm());
        stage.setScene(scene);
        stage.show();*/
        
        
        
         FirstController roots = new FirstController();
        roots.setStages(stage);
        
       // FXMLLoader loader=new FXMLLoader();
        stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("SecondDocument.fxml"));
        //FXMLDocumentController controller=loader.getController();
//        controller.setStages(stage);
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
        
        
        
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
