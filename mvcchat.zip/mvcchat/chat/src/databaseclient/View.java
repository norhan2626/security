/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.awt.image.BufferedImage;

import java.io.ByteArrayOutputStream;
import java.io.File;

import java.io.IOException;

import java.io.UnsupportedEncodingException;

import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;

import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.fxml.Initializable;
import javafx.geometry.Pos;

import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;

import javafx.scene.image.Image;

import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 *
 * @author Dan
 */
public class View implements Initializable {

    @FXML
    private AnchorPane anchorPane;
    @FXML
    private Text namid;

    @FXML
    private Label label;

    @FXML
    private TextArea sendText;
    @FXML
    private Image defult;
    @FXML
    private VBox chatBox;

    @FXML
    private ImageView imag;
    @FXML
    private Image images;
    @FXML
    private String im1;
    @FXML
    private ScrollPane scroll;

    private List<HBox> messages = new ArrayList<>();

    private volatile int index = 0;
    String imageUrl;
    Stage stage;
    Model client;
    ClientInt c;
    Controller controller;
    ChatServerInt interfaceserver;

    public View() {

    }

    public void setStage(Stage stages) {

        this.stage = stages;

      

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        controller = new Controller(this);

        System.out.println("Connected to Server");
        namid.setText(FirstController.nameString);
        sendText.setOnKeyReleased(new EventHandler<javafx.scene.input.KeyEvent>() {
            @Override
            public void handle(javafx.scene.input.KeyEvent event) {

                if (event.getCode().equals(KeyCode.ENTER)) {

                    sendMessage();
                }
                if (event.getCode().equals(KeyCode.SHIFT)) {

                    String strr = sendText.getText();
                    sendText.appendText("\n");

                }

            }

        });
        if (FirstController.image1 != null) {
            imag.setImage(FirstController.image1);
        }

        chatBox.setId("chatBox");

    }

    public void sendMessage() {

        String str = sendText.getText();
        String replaceAll = str.replaceAll("\\s+", "");

        if (replaceAll.equals("")) {

        } else {

            HBox hBox = new HBox();
            hBox.setAlignment(Pos.BASELINE_RIGHT);
            Text t = new Text(sendText.getText());
            Label lab = new Label(FirstController.nameString);
            lab.setStyle("-fx-background-color:POWDERBLUE");
            System.out.println("image" + imag.getImage());

            ImageView imageView = new ImageView(imag.getImage());
            Messagedata message = new Messagedata(lab.getText(), str, imag.getImage());
//Messagedata message= new Messagedata(FirstController.nameString,sendText.getText(),imaggg);
            System.out.println("nour" + message);
            try {
                System.out.println("try---" + controller.toString());
                controller.sendMsg(message);

            } catch (RemoteException ex) {
                Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            }
            imageView.setFitHeight(20);
            imageView.setFitWidth(20);
            hBox.getChildren().addAll(t, imageView, lab);
            messages.add(hBox);
            messages.get(index).setAlignment(Pos.BASELINE_RIGHT);
            chatBox.getChildren().add(messages.get(index));
            index++;
            chatBox.heightProperty().addListener((observable, oldValue, newValue) -> {
                scroll.setVvalue((double) newValue);
            });
            sendText.clear();

        }
    }

    public void display(Messagedata msg) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {

                Image image;

                if (FirstController.im1.equals("noImage")) {
                    image = defult;

                } else {
                    image = new Image(FirstController.im1);
                }

                //   ImageView imageView = new ImageView(image);
                ImageView imageView = new ImageView(msg.getImage());

                System.out.println("msg=" + msg);
//                System.out.println("image is "+image.getHeight());
                HBox hBox = new HBox();
                hBox.setAlignment(Pos.BASELINE_LEFT);
                // Label lab = new Label(FirstController.nameString);

                Label lab = new Label(msg.getName());
                lab.setStyle("-fx-background-color:POWDERBLUE");

                Text t = new Text("  " + msg.getMessage());

                t.setStyle("-fx-background-color:POWDERBLUE");
                imageView.setFitHeight(20);
                imageView.setFitWidth(20);

                hBox.getChildren().addAll(imageView, lab, t);

                messages.add(hBox);
                messages.get(index).setAlignment(Pos.CENTER_LEFT);
                chatBox.getChildren().add(messages.get(index));
                chatBox.heightProperty().addListener((observable, oldValue, newValue) -> {
                    scroll.setVvalue((double) newValue);
                });
                index++;

            }
        });
    }

    @FXML
    private void sendAction(ActionEvent event) throws IOException {

        sendMessage();

    }

}
