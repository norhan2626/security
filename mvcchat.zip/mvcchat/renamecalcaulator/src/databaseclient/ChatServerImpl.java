/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;

/**
 *
 * @author Dan
 */
public class ChatServerImpl extends UnicastRemoteObject implements ChatServerInt {

    Vector<ClientInt> clientsVector = new Vector<ClientInt>();

    public ChatServerImpl() throws RemoteException {

    }

    @Override
    public void tellOthers(Messagedata msg) throws RemoteException {
        System.out.println("Messge received: " + msg);
        for (ClientInt clientRef : clientsVector) {
          if (clientRef == msg.getClient()) {
                
            }
         else{ clientRef.receive(msg);
            System.out.println("we are here");
            
        }
    }}

    @Override
    public void register(ClientInt clientRef) {
        clientsVector.add(clientRef);
        System.out.println("Client added ");

    }

    @Override
    public void unRegister(ClientInt clientRef) {
        clientsVector.remove(clientRef);
        System.out.println("Client removed");
    }
}
