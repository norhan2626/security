/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseclient;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


/**
 *
 * @author Dan
 */



public class Server { 
   
 
   public static void main(String args[]) throws ClassNotFoundException { 
    
          new Server();

    }

   public  Server () {
        try {
            ChatServerImpl obj = new ChatServerImpl();
            Registry reg = LocateRegistry.createRegistry(1800);
            reg.rebind("chat1", obj);
        } catch (RemoteException ex) {
            ex.printStackTrace();
        }
   

}

}
      
    